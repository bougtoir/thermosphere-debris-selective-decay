# Submission package manifest

Generated (UTC): 2026-10-17T10:10:50Z
Repository: https://github.com/bougtoir/thermosphere-debris-selective-decay

Contents:

- `01_manuscript/manuscript.docx` — journal version; figures are supplied as separate files (placeholders + caption list in text).
- `01_manuscript/manuscript_inline_figures.docx` — same text with all figures and tables placed inline for reading/review.
- `01_manuscript/manuscript_figures_editable.pptx` — editable English slide deck of all figures and key results.
- `02_supplement/` — supplementary figures and tables.
- `03_submission_docs/` — cover letter, highlights, checklists, declarations, data/code availability, journal audit, hostile reviews, reanalysis plan and QC audits.
- `04_figures/` — standalone figure files (PNG, 200 dpi).
- `05_references/` — verified reference list with DOIs.
- `06_data/` — data dictionary, case definitions, all result tables (CSV), and value-level manuscript provenance.
- `07_code/` — full analysis code, config and environment files; `make all` regenerates every number, figure and table.

All quantitative statements in the manuscript are written from the CSVs in `06_data/tables/` by `07_code/scripts/build_manuscript.py`; no scientific number is hard-coded.

## Checksums (SHA-256)

| file | bytes | sha256 |
| --- | --- | --- |
| 01_manuscript/manuscript.docx | 57408 | e6db98af043f0f9256de87a0154935d7f7f0d6a7d2394b77eb50fdbd0f0937ae |
| 01_manuscript/manuscript_figures_editable.pptx | 762423 | 6bdcc1b0561f7022d7676ad4807bd231f9321e9d7881dba2fdcee97249e417cb |
| 01_manuscript/manuscript_inline_figures.docx | 614693 | 2b46784b9f6fcbc9c1929e276cc9741fcbf3a86cd6605177eca258c00f1b247a |
| 02_supplement/supplement.docx | 213434 | 249363fd1e2ea9f973cb229074d668ff07c561c50c7c269c74fdedcbe9bac907 |
| 03_submission_docs/ADVERSARIAL_REVIEW.md | 2590 | 32c497bf8cd2217be57eaf8ffbb2236a49cfa82fad43bf5594f6ebdae45c579b |
| 03_submission_docs/CONSISTENCY_AUDIT.md | 382 | bf215e5a69dc8ea81047c814256cd9fa6d90490ebd73b9c778f2443a8411371a |
| 03_submission_docs/COVER_LETTER.md | 1500 | e6403883986b25c88324a8cc0e0780be48a8a75629026be0ead6297bb3877631 |
| 03_submission_docs/DATA_CODE_AVAILABILITY.md | 2175 | 10177d0f0d756892b639b14a9a1ade3c38a86d19a348b2794765394d957270fc |
| 03_submission_docs/DECISION_LOG.md | 1932 | c15e96cbe2d6975e8551c127b162280cdd5284105cdcae6948013a7dac2dcabb |
| 03_submission_docs/DECLARATIONS.md | 1944 | b5cb2e97c56673a27e11be08a71efffc96f0d207a853b7a25c41aaf84222870f |
| 03_submission_docs/FINAL_DECISION_LOG.md | 7455 | 182ddc90d946ac3ff112743d9f7976e062ebad1f9680b938f7c611d33927777b |
| 03_submission_docs/FINAL_SUBMISSION_CHECKLIST.md | 5047 | 897d33e0a74e6c6c4501b146d4974eb9d04df3191c26aa5d37e0755c4ec58886 |
| 03_submission_docs/HIGHLIGHTS.md | 623 | 4cffd0a265a6661479f7299ac2f00d268d2a60cfdbaf9f62d16462a0140dee1f |
| 03_submission_docs/HOSTILE_REVIEW_POST.md | 8243 | 89d00cdbd9491a93f11f9b45ec28126c69c7ed63003ddde9340987613a2e8ee6 |
| 03_submission_docs/HOSTILE_REVIEW_PRE.md | 10243 | 696cfcaa16084527782298f4ed5b87b72bd6782dd72343daee6672f2a7c70216 |
| 03_submission_docs/JOURNAL_AUDIT.md | 5812 | 15e80ce57abde014151b5cdf6472d1442f26f530db2f56cb31938ccc03444d5e |
| 03_submission_docs/NUMERICAL_ZERO_AUDIT.md | 4647 | 3ab8adb555a3bf29427228916b961e425c21e4a0a2b771e06141987ca77ebe82 |
| 03_submission_docs/PRE_REVISION_STATE.md | 5987 | b6c302c7e9d8affc2d1f83b5b69a99f71cb2fd0e5ef54659f192521432c493b7 |
| 03_submission_docs/REANALYSIS_PLAN.md | 7300 | 0fffc242adf5d399516f6a1da14cb9689494250d2659c194b7790900fe707154 |
| 03_submission_docs/REPRODUCIBILITY_AUDIT.md | 176 | 6f2972bdb33f03ef07dca405f6ac5968d42b433fab9c7ca26a07a07e0b043c62 |
| 03_submission_docs/REVIEWER_RISK.md | 1228 | ff1ce30c637c54734b79a54f36e3177cbbc50ddaeaf325f8737ff7fd7ebd036b |
| 03_submission_docs/REVIEW_FIXES_AUDIT.md | 8886 | bbd9f358ca2ec6b3188a199e0a87ce85451e82b94e20c0161ae2089d00212491 |
| 03_submission_docs/SCALING_LAW_AUDIT.md | 4309 | 57ea673fb65ec7370d6cfabe958f9618dc8e2c7133ddb8cca943dcf226621e2c |
| 03_submission_docs/SOBOL_AUDIT.md | 7638 | dece77e8247ff91af1161f126f9e83b19fbb4cf31704cfde3a5e4ac71690dfb1 |
| 03_submission_docs/SUBMISSION_CHECKLIST.md | 1214 | 90aa54c7613f11f57a4fd5e87dc5f68d784aa3e626d4432b6c9e2168cded93e6 |
| 03_submission_docs/TRACEABILITY_AUDIT.md | 2122 | 774c13bb9735db064a2c171c50f7567fb729ce95ad7f2f370876bdf5d8126c0a |
| 03_submission_docs/TRANSPORT_BOUNDARY_AUDIT.md | 4784 | 08110e7df53d6ac149397b313b5960145d0a85feb532cb35924c20984534c61a |
| 04_figures/fig1_density_profiles.png | 90730 | 98d2ed52c7f65ce31b5f9a557e21881716232084e768788bcce92de5ac6e77cb |
| 04_figures/fig2_lifetime_map.png | 49477 | 13894e87c9acf588b3e6413b7a875c2dd4915706cb1dd5d63128edf018c78e9c |
| 04_figures/fig3_collateral.png | 49314 | a5a5f756854b9991c0e83d870c6f676c1ed109b0307007e06c30fc9f2ffea760 |
| 04_figures/fig4_timing.png | 64673 | d6377a13011c742a13bfbf523dfb16196a5019d53a3374cb571ed7515cfe997c |
| 04_figures/fig5_pareto.png | 66980 | eab5ad43dbf2bc1e857c03bcbfd430b6cced2bea3c9caa73bb09db67a27cbec1 |
| 04_figures/fig6_scaling_collapse.png | 77949 | 510454e1b81d57d72c2dc1070f3c505219ef70a306b474141c7e4d025bacb41b |
| 04_figures/fig7_matched_exposure.png | 53733 | f84b3a1261a4fd956e7be38a0eac54640a64b39b0e6eabd745705db755ffd252 |
| 04_figures/fig8_energy_bounds.png | 163008 | 375719119b42c5e7b84f3ac40c49711a93b98e95a2b1e68cbb5f535365c2d7b5 |
| 04_figures/figS1_negative_controls.png | 85417 | 83388cd7a9454fec1cb1400d18f156b382f6d72f6692e347b61a4634b56b4ab1 |
| 04_figures/figS2_mc_hist.png | 22878 | 67eb3bf9c1f334f4d2ae8bd54e46ed6890587157108411c9023312db135815e3 |
| 04_figures/figS3_sobol.png | 49060 | 33fb581f912d04736e5ffe183997be8975063358ef62247765ff57658714df15 |
| 04_figures/figS4_transport_grid_sensitivity.png | 39881 | 1e90eb4fc483d3f6e29f3515946a150a5a8454353da1332b75010ab928514eea |
| 05_references/references_verified.csv | 5636 | 85f565f70a6f2a4d8fe25a4c9f22b1d3200a12819faeb381b22fb44bf8453342 |
| 06_data/DATA_DICTIONARY.md | 9245 | ea2bcb8fc569a1c6c5deb577cb673765a1575a99ffb3281618870c1784f25a00 |
| 06_data/cases.csv | 1347 | a7813324cb7508a988195f815f5b760bee07854796af4b997886cd5aa671478c |
| 06_data/manuscript_citations.csv | 325 | 0f3ebac9fee9a2316a49217b7175b036e9ad56568bc8323ff46b73b9c50ff317 |
| 06_data/manuscript_value_provenance.csv | 7353 | 177c669390791f1bf8badadea0d0ac317bc4d97e1c59d0bf281a3dc521e605c9 |
| 06_data/tables/energy_bounds_audit.csv | 10752 | 358afbf67377f1b8d80b1a7844d643a532eaad018768c2a8cf1569b842772765 |
| 06_data/tables/gap_decomposition.csv | 519 | 1b7b61bd770ddca441fbfef99db0202b7e0629bb8ec7717cec430b2cf11cd35a |
| 06_data/tables/gap_decomposition_factors.csv | 464 | ef83aecbe530c6f519b34ad8f0ab641d75a0af96574bda4d9355101eedaf0f19 |
| 06_data/tables/master_results.csv | 980769 | e14a8c123c157900a98798872207c821dbb49a7a0da685ce37f4ff7319daae9f |
| 06_data/tables/matched_exposure.csv | 5816 | 1e1d7208dcd844e423f1a052497bae5f467c4e7db6ed978e4c8a2dac5e1dcbe5 |
| 06_data/tables/numerical_zero_audit.csv | 2612 | e6198ea3230b2a57e5b378cf79048ca418fc99e373b6bf22a8bed697978bb2a9 |
| 06_data/tables/orbit_step_convergence.csv | 746 | 481297c1dafe7affc26ccc00c1384415670365b5939a01de861a25bf25865d93 |
| 06_data/tables/phase10_montecarlo.csv | 38848 | a9df93af6d02410f964a377eb3b1dfd296d3ac5e89e84c3e47ffffe307aecc8c |
| 06_data/tables/phase10_negative_controls.csv | 627 | 8242507ffe710a8deaa56b6cf26ad4d6dfd379b568967ca2193900e29b36f16b |
| 06_data/tables/phase10_sobol.csv | 669 | f616a8139320f575eadfa0f268750dd012b66a12379d33f8762fa81b1881cf73 |
| 06_data/tables/phase11_scaling.csv | 74174 | c049c99120a1b9e2f871433f9a6e765ebb5e72015bf4c279db82c88888fb73df |
| 06_data/tables/phase11_scaling_fit.csv | 212 | dab262e5ed5771a6aff5329b96d6ea900e5224dbd4f3b2a58bf8b9571f19d5ca |
| 06_data/tables/phase12_classification.csv | 267951 | fe5b68f401eef3582d65285252da8569c89285108a02efe4adabebde22cb3d13 |
| 06_data/tables/phase1_density_table.csv | 3851 | adfaeffc1d930e7b8c9ce1fc45fd02de2060ed3fb5cf53504a8874c197fbcc8a |
| 06_data/tables/phase1_energy_bounds.csv | 8405 | 46dd7a0a4438e5144dcefdf356e6ae22e114a44da6d605d1d6322940fec6ec73 |
| 06_data/tables/phase1_scale_calculations.csv | 19536 | ee2619a2aa9deacd1063b5f1bfd5ff6dfe2fba371e49b3e34b159b2e41cd1e8a |
| 06_data/tables/phase2_validation.csv | 769 | ccf3f51bd239d6f4077698bb9e62b20713d4645d8ffc7e2c31de4bf5e270d505 |
| 06_data/tables/phase3_intervention_checks.csv | 328 | 3e64a1b65f9541b40333d5db56d35ccd950fe0ede2cacaf070978f9a5650b22d |
| 06_data/tables/phase5_spreading.csv | 1060 | c6461aa26e18f597dc0eb3994641e6b508a50bb2de6ca6f1d76a81dc708f1c78 |
| 06_data/tables/phase6_outcomes.csv | 10459 | 6abd87b5d1d67163bca0fa73a7c5eea53a29854a688668845e7d2fa06c374e83 |
| 06_data/tables/phase7_controls.csv | 2736 | 30e52b0ce4453d562b08b35d4835610bee43ba0474dcb51aad38bdb3b5355522 |
| 06_data/tables/phase7_selectivity.csv | 1468 | b5b1e352f1bc748264734333909969366bff5bf459656bfea5140a0a19351c2d |
| 06_data/tables/phase8_timing.csv | 7040 | a8fa265b095b5f69254a2e0a437f27094e4a0d4bc973aa6d6d287e9c61890f4f |
| 06_data/tables/phase9_pareto.csv | 7413 | 0195637a8ca4b1a46ebb3ca25d7126843edb20799c9a9cd155a92d6d891a3a13 |
| 06_data/tables/quick_summary.csv | 643 | b2d85db2b2b322c404637bcc7a86a87215d3027c4b0829b4e7401c64e8b51314 |
| 06_data/tables/selectivity_classified.csv | 1124 | e3a2481b1f6a5c33c83a04696ede7e8890cae5542e9373f5e1d6c328edbd186c |
| 06_data/tables/sobol_convergence.csv | 6188 | 2ecc354319195eb656f5231849db7c8d79636ac406145c37e8b57e056fefbddc |
| 06_data/tables/sobol_reproduction_check.csv | 1619 | 55f484756c51acdc5cb6f8b3037c15f1a2018b57623f29cc9336d677f2c6edec |
| 06_data/tables/transport_boundary_sensitivity.csv | 13306 | 9e5ca2faeebefbf534f9d06914abd800656dc194733c29f2bed6108b11286f95 |
| 07_code/Makefile | 1913 | 8e320502ab38dc80d31a3df2b6490d39317544ae645f2618c5a56c336170362b |
| 07_code/config/default.yaml | 2313 | 37258ec4dbed4e6c8c608ce3b10f69e6c46587f4bd0ea8f4f7c5b76e4643c3f8 |
| 07_code/environment.yml | 127 | a3386ac5e5d0bf984108d04b57eefdf492e003f19f996bc991fb816f92c9eaa9 |
| 07_code/requirements.txt | 185 | 56aca0f82dc7c3ea9a067a2db6bbf24c344625051e27e9a21198d6c9e88d9ea6 |
| 07_code/scripts/audit_energy.py | 5501 | 43d80ee00c105bc37151920e876c20f475e88eb3d1033d72d812ad4e0b0538ac |
| 07_code/scripts/audit_gap_decomposition.py | 6620 | 8aa76a8a9cee3277e727266b9a8a67defad71c46995374cde8f9e8a82042043f |
| 07_code/scripts/audit_matched_exposure.py | 5279 | def525f7d546f324ecdd422b033f2f40118c466d12e393ca905bbd21d892acd3 |
| 07_code/scripts/audit_numerical_zero.py | 5233 | 07428de65e588344839f5c34d7b5dcf53962739369d2c30cf74fe2e3948a4ee3 |
| 07_code/scripts/audit_orbit_convergence.py | 3565 | 57efa841e7eab773d721878d576af37c3aaef30af7a5d0a7a38859d078e18ede |
| 07_code/scripts/audit_sobol.py | 6269 | 6c42c487200e99cbef128f0e4c6c5af63700faef447e2f37256c22e2b9d4b3af |
| 07_code/scripts/audit_transport_boundary.py | 4646 | 555ad8eb0f772d840b43af750244e5b2addafba931e4c31033bc1a50b79d88eb |
| 07_code/scripts/build_manuscript.py | 60868 | 16fe9171acdf33a735c5d004c2bbe919765ee490bda17ab105283392a346220e |
| 07_code/scripts/build_submission_package.py | 8010 | 158cfb137568490fba5c5cce608c57ea9a681d0a68927bdcd0f80f351d73058b |
| 07_code/scripts/phase01_feasibility_audit.py | 12134 | 9d75de104fa5645960ad12151bc4c79c02b1f65ef9485a64ef0eef72a54cb922 |
| 07_code/scripts/phase02_baseline_validation.py | 8795 | 5ef242af79c08f766418297d228717ed94ce401fec49dc8f363b718758a1b790 |
| 07_code/scripts/phase03_intervention_check.py | 4016 | 40e4a9da62e5a38f7b1f57d93f31409ba1d8dd1d451b17ca0ba665f2532a0e93 |
| 07_code/scripts/phase04_populations.py | 4361 | b99ab9458e15fe4aa04ba774a5ea336563abd4684b7079b936a076faa62921d6 |
| 07_code/scripts/phase05_spreading.py | 4451 | 9133a8e8f6bbdbd1176240c5deb5aedbcb6d4181bfb8f7258c59a516dd7d39d6 |
| 07_code/scripts/phase06_outcomes.py | 5422 | 08697bfe633f2e4a42e3ec70d0810da3990cd42872c4540d0376116de00dc577 |
| 07_code/scripts/phase07_controls.py | 8566 | 6a2e4e7d14969f74afeb4edea7e8856a35acda0d619b036b3c3284f56d1b4ccf |
| 07_code/scripts/phase08_timing.py | 5007 | a665eaeeb15571e73c8385b5a7a3ef07a3a9e340c0d2d44809901bef244269d5 |
| 07_code/scripts/phase09_pareto.py | 4008 | 4dd977be692fbac211125b0c26445703f563541e5cd910cdb1216db75a173a43 |
| 07_code/scripts/phase10_uncertainty.py | 7493 | 1fac4a96e26d2117199b7fbb84b678475b94a47f01c548118009d543a1d11ad0 |
| 07_code/scripts/phase11_scaling.py | 4857 | 5de016539c81013fb9cc3897790b38f361d7d18865c8cc97b7bd6c99e5e2279f |
| 07_code/scripts/phase12_classification.py | 4674 | 19e4629abdc7fc478aa03ba53fe22d36eaad2e199af272576c71bf1b860b6304 |
| 07_code/scripts/phase13_results.py | 13004 | fd37e58388250b8023c67525ceac8acc46b74bd9da587c2e8c3eed6ddb55da77 |
| 07_code/scripts/qc_traceability.py | 9522 | 53e5d676816630099155653bfb00e57d37ea62b50a6f331b55ba5da0ed56f28e |
| 07_code/scripts/run_quick.py | 3971 | 8b6b3f91a8126206d3490118a12d3ed790dc0f03d28625fb70e594f06e9aa4ec |
| 07_code/src/__init__.py | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| 07_code/src/analysis/__init__.py | 50 | 957c87354bcc53404864aa8799d77101ca263d2e2ab41c62f1f7c9647393ce37 |
| 07_code/src/analysis/exposure_class.py | 4907 | 04dc0f95ce810f94b1d7a458d2a43d9d89a101fe86abe581ea8607cbe9c9f260 |
| 07_code/src/atmosphere/__init__.py | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| 07_code/src/atmosphere/lookup.py | 2744 | de741f02d4c557e1c567ae85bbac340881d7e4d8bc4131c0980dd7d3522b6504 |
| 07_code/src/atmosphere/msis.py | 3227 | a4e1ec3e5cef291b46c4ea59b92af09ea79474a26ec0ec63971760d664855c0d |
| 07_code/src/energy/__init__.py | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| 07_code/src/energy/bounds.py | 2364 | d3824fea169c76b4014c8ea4d130bb7c8e786e9969dbc7eb5460b12401c8ae56 |
| 07_code/src/experiment.py | 2633 | 1eee99a6326f68e1c95cf99f39d143f5b48bcac532560a23449f183e06673bac |
| 07_code/src/intervention/__init__.py | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| 07_code/src/intervention/models.py | 7120 | 0deae6dae875fd43452f791d7541855abada7929269b8c23376646e2f06073c9 |
| 07_code/src/optimization/__init__.py | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| 07_code/src/orbits/__init__.py | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| 07_code/src/orbits/elements.py | 3838 | 8ff687a5a808508b103b1ee821e5b4ebb9364ce1040bbb921878127eb241e1fa |
| 07_code/src/orbits/fastprop.py | 12427 | bd0cbe1386a25662346a737924ab1cef971878e72ee0b8660ba8bf345e4d23a0 |
| 07_code/src/orbits/propagator.py | 2891 | c16ff678b302f57c61d6bec4b9e48c8a18b86adbff604f85541d9ace25bf3a36 |
| 07_code/src/uncertainty/__init__.py | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| 07_code/src/uq/__init__.py | 42 | 33da62073788f978b820b9b4fe8949f28517bd00e932139a70316c8a48e2707f |
| 07_code/src/uq/sobol_response.py | 4029 | 093e3517c76a161c8fb8ff31b9ac124bf5914759ed231e8a929cb75267835ea4 |
| 07_code/src/utils.py | 779 | 50f31122af34fcd21bed0120b4c2c1c2f5dcb47575b3d7273f37562eeab1f8d3 |
| 07_code/tests/__init__.py | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 |
| 07_code/tests/test_atmosphere_units.py | 1362 | 209b307259034b7292a435485e6d946ec7bca3f30c36abd900e8ddc205c78d40 |
| 07_code/tests/test_core.py | 3074 | c544d0244654c8e7489e5646fb58eba1b17914ef8b4bc91507f261704027195f |
| 07_code/tests/test_numeric_provenance.py | 3882 | f087f4f8f28e95a099904ecace23d40145a24360ff6844c67dc471c1f86709cd |
| 07_code/tests/test_review_fixes.py | 5374 | 99d0f39bb428d21bce79efb31cce00b45a976a864aa68f010e03bdafb131a129 |
| CITATION.cff | 382 | 8094c081db5108fc8fd0d167193ec4525a3e701dbfd5655cea1db985295598fa |
| LICENSE | 1071 | 52b8d0b03c5e63f964ae171c0dc76c11c923583cea8a972591ee28e2b790856e |
| README.md | 1949 | 241c79c129da33f8f840cb4066c0721940ffad2b39083b5724c3cfeadd5f33ec |
