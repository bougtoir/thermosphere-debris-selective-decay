"""Uncertainty-quantification helpers."""
