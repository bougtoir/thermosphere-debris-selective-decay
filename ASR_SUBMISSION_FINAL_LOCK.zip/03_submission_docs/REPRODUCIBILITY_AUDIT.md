# Reproducibility audit

- scanned 93 source/doc files
- PASS no absolute paths, credentials, or unpinned requirements (0 hits)
- PASS deterministic seed in config/default.yaml