"""Assemble the journal submission package (submission/ + zip).

Collects the manuscript (journal version with figures as separate files,
plus an inline-figure reading copy), the editable English slide deck, the
supplement, standalone figure files, tables, verified references and the
submission documentation, then writes a manifest with SHA-256 checksums
and a single zip archive.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import sys
import zipfile
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from src.utils import repo_root  # noqa: E402

ITEMS = [
    ("manuscript/manuscript.docx", "01_manuscript/manuscript.docx"),
    ("manuscript/manuscript_inline.docx",
     "01_manuscript/manuscript_inline_figures.docx"),
    ("manuscript/manuscript_figures.pptx",
     "01_manuscript/manuscript_figures_editable.pptx"),
    ("supplement/supplement.docx", "02_supplement/supplement.docx"),
    ("docs/COVER_LETTER.md", "03_submission_docs/COVER_LETTER.md"),
    ("docs/HIGHLIGHTS.md", "03_submission_docs/HIGHLIGHTS.md"),
    ("docs/SUBMISSION_CHECKLIST.md",
     "03_submission_docs/SUBMISSION_CHECKLIST.md"),
    ("docs/FINAL_SUBMISSION_CHECKLIST.md",
     "03_submission_docs/FINAL_SUBMISSION_CHECKLIST.md"),
    ("docs/DECLARATIONS.md", "03_submission_docs/DECLARATIONS.md"),
    ("docs/DATA_CODE_AVAILABILITY.md",
     "03_submission_docs/DATA_CODE_AVAILABILITY.md"),
    ("docs/JOURNAL_AUDIT.md", "03_submission_docs/JOURNAL_AUDIT.md"),
    ("docs/ADVERSARIAL_REVIEW.md",
     "03_submission_docs/ADVERSARIAL_REVIEW.md"),
    ("docs/REVIEWER_RISK.md", "03_submission_docs/REVIEWER_RISK.md"),
    ("docs/DECISION_LOG.md", "03_submission_docs/DECISION_LOG.md"),
    ("docs/FINAL_DECISION_LOG.md",
     "03_submission_docs/FINAL_DECISION_LOG.md"),
    ("docs/HOSTILE_REVIEW_PRE.md",
     "03_submission_docs/HOSTILE_REVIEW_PRE.md"),
    ("docs/HOSTILE_REVIEW_POST.md",
     "03_submission_docs/HOSTILE_REVIEW_POST.md"),
    ("docs/REANALYSIS_PLAN.md", "03_submission_docs/REANALYSIS_PLAN.md"),
    ("docs/PRE_REVISION_STATE.md",
     "03_submission_docs/PRE_REVISION_STATE.md"),
    ("docs/SOBOL_AUDIT.md", "03_submission_docs/SOBOL_AUDIT.md"),
    ("docs/NUMERICAL_ZERO_AUDIT.md",
     "03_submission_docs/NUMERICAL_ZERO_AUDIT.md"),
    ("docs/TRANSPORT_BOUNDARY_AUDIT.md",
     "03_submission_docs/TRANSPORT_BOUNDARY_AUDIT.md"),
    ("docs/SCALING_LAW_AUDIT.md",
     "03_submission_docs/SCALING_LAW_AUDIT.md"),
    ("docs/REVIEW_FIXES_AUDIT.md",
     "03_submission_docs/REVIEW_FIXES_AUDIT.md"),
    ("docs/TRACEABILITY_AUDIT.md",
     "03_submission_docs/TRACEABILITY_AUDIT.md"),
    ("docs/REPRODUCIBILITY_AUDIT.md",
     "03_submission_docs/REPRODUCIBILITY_AUDIT.md"),
    ("docs/CONSISTENCY_AUDIT.md",
     "03_submission_docs/CONSISTENCY_AUDIT.md"),
    ("references/references_verified.csv",
     "05_references/references_verified.csv"),
    ("data/processed/DATA_DICTIONARY.md",
     "06_data/DATA_DICTIONARY.md"),
    ("data/processed/cases.csv", "06_data/cases.csv"),
    ("results/manuscript_value_provenance.csv",
     "06_data/manuscript_value_provenance.csv"),
    ("results/manuscript_citations.csv",
     "06_data/manuscript_citations.csv"),
    ("README.md", "README.md"),
    ("CITATION.cff", "CITATION.cff"),
    ("LICENSE", "LICENSE"),
    ("requirements.txt", "07_code/requirements.txt"),
    ("environment.yml", "07_code/environment.yml"),
    ("Makefile", "07_code/Makefile"),
    ("config/default.yaml", "07_code/config/default.yaml"),
    # ---- audit evidence (required for the evidence-verified package) --
    ("docs/HOSTILE_REVIEW_FINAL.md",
     "08_audit_evidence/HOSTILE_REVIEW_FINAL.md"),
    ("docs/HOSTILE_REVIEW_INDEPENDENT.md",
     "08_audit_evidence/HOSTILE_REVIEW_INDEPENDENT.md"),
    ("docs/HARDCODE_AUDIT.md",
     "08_audit_evidence/HARDCODE_AUDIT.md"),
    ("docs/DATA_TEXT_FIGURE_CONSISTENCY.md",
     "08_audit_evidence/DATA_TEXT_FIGURE_CONSISTENCY.md"),
    ("docs/DYNAMIC_PROVENANCE_TEST.md",
     "08_audit_evidence/DYNAMIC_PROVENANCE_TEST.md"),
    ("docs/REPRODUCIBILITY_AUDIT_FINAL.md",
     "08_audit_evidence/REPRODUCIBILITY_AUDIT_FINAL.md"),
    ("docs/RENDER_AND_CONSISTENCY_FINAL.md",
     "08_audit_evidence/RENDER_AND_CONSISTENCY_FINAL.md"),
    ("docs/RENDER_FINAL.md", "08_audit_evidence/RENDER_FINAL.md"),
    ("docs/RENDER_AND_CONSISTENCY_AUDIT.md",
     "08_audit_evidence/RENDER_AND_CONSISTENCY_AUDIT.md"),
    ("docs/FINAL_QC_BASELINE.md",
     "08_audit_evidence/FINAL_QC_BASELINE.md"),
    ("docs/FINAL_SOURCE_LOCK.md",
     "08_audit_evidence/FINAL_SOURCE_LOCK.md"),
    ("docs/BASELINE_FREEZE.md",
     "08_audit_evidence/BASELINE_FREEZE.md"),
    ("docs/FINAL_REMEDIATION_LOG.md",
     "08_audit_evidence/FINAL_REMEDIATION_LOG.md"),
    ("docs/ROOT_CAUSE_AND_REANALYSIS.md",
     "08_audit_evidence/ROOT_CAUSE_AND_REANALYSIS.md"),
    ("docs/EVIDENCE_INVENTORY.md",
     "08_audit_evidence/EVIDENCE_INVENTORY.md"),
    ("results/numeric_claim_traceability.csv",
     "08_audit_evidence/numeric_claim_traceability.csv"),
    ("results/hardcode_findings.csv",
     "08_audit_evidence/hardcode_findings.csv"),
    ("results/evidence_inventory.csv",
     "08_audit_evidence/evidence_inventory.csv"),
    ("logs/final_qc_commands.log",
     "08_audit_evidence/final_qc_commands.log"),
    ("logs/make_all.log", "08_audit_evidence/make_all.log"),
    ("FINAL_HANDOFF.txt", "08_audit_evidence/FINAL_HANDOFF.txt"),
]

FIG_DIR = "results/figures"
TAB_DIR = "results/tables"
CODE_DIRS = ["src", "scripts", "tests"]


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    root = repo_root()
    missing = [src for src, _ in ITEMS
               if not os.path.exists(os.path.join(root, src))]
    if missing:
        raise SystemExit(
            "submission package incomplete — required files missing:\n  "
            + "\n  ".join(missing)
            + "\nRun `make all` to regenerate them.")
    pairs = [(os.path.join(root, src), dst) for src, dst in ITEMS]

    out = os.path.join(root, "submission")
    if os.path.exists(out):
        shutil.rmtree(out)
    os.makedirs(out)

    for fn in sorted(os.listdir(os.path.join(root, FIG_DIR))):
        if fn.endswith(".png") and not fn.startswith("quick_"):
            pairs.append((os.path.join(root, FIG_DIR, fn),
                          f"04_figures/{fn}"))
    for fn in sorted(os.listdir(os.path.join(root, TAB_DIR))):
        if fn.endswith(".csv"):
            pairs.append((os.path.join(root, TAB_DIR, fn),
                          f"06_data/tables/{fn}"))
    for d in CODE_DIRS:
        for dirpath, _, files in os.walk(os.path.join(root, d)):
            if "__pycache__" in dirpath:
                continue
            for fn in files:
                if fn.endswith((".py", ".yaml", ".md")):
                    sp = os.path.join(dirpath, fn)
                    rel = os.path.relpath(sp, root)
                    pairs.append((sp, f"07_code/{rel}"))

    for sp, dst in pairs:
        dp = os.path.join(out, dst)
        os.makedirs(os.path.dirname(dp), exist_ok=True)
        shutil.copy2(sp, dp)

    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    lines = [
        "# Submission package manifest",
        "",
        f"Generated (UTC): {stamp}",
        "Repository: https://github.com/bougtoir/"
        "thermosphere-debris-selective-decay",
        "",
        "Contents:",
        "",
        "- `01_manuscript/manuscript.docx` — journal version; figures are "
        "supplied as separate files (placeholders + caption list in text).",
        "- `01_manuscript/manuscript_inline_figures.docx` — same text with "
        "all figures and tables placed inline for reading/review.",
        "- `01_manuscript/manuscript_figures_editable.pptx` — editable "
        "English slide deck of all figures and key results.",
        "- `02_supplement/` — supplementary figures and tables.",
        "- `03_submission_docs/` — cover letter, highlights, checklists, "
        "declarations, data/code availability, journal audit, hostile "
        "reviews, reanalysis plan and QC audits.",
        "- `04_figures/` — standalone figure files (PNG, 200 dpi).",
        "- `05_references/` — verified reference list with DOIs.",
        "- `06_data/` — data dictionary, case definitions, all result "
        "tables (CSV), and value-level manuscript provenance.",
        "- `07_code/` — full analysis code, config and environment files; "
        "`make all` regenerates every number, figure and table.",
        "",
        "All quantitative statements in the manuscript are written from "
        "the CSVs in `06_data/tables/` by `07_code/scripts/"
        "build_manuscript.py`; no scientific number is hard-coded.",
        "",
        "## Checksums (SHA-256)",
        "",
        "| file | bytes | sha256 |",
        "| --- | --- | --- |",
    ]
    for _, dst in sorted(pairs, key=lambda p: p[1]):
        dp = os.path.join(out, dst)
        lines.append(f"| {dst} | {os.path.getsize(dp)} | {sha256(dp)} |")
    with open(os.path.join(out, "MANIFEST.md"), "w") as f:
        f.write("\n".join(lines) + "\n")

    zip_path = os.path.join(root, "submission/ASR_final_submission.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for dirpath, _, files in os.walk(out):
            for fn in files:
                sp = os.path.join(dirpath, fn)
                if os.path.abspath(sp) == os.path.abspath(zip_path):
                    continue
                z.write(sp, os.path.relpath(sp, out))
    print(f"submission package: {len(pairs) + 1} files -> {zip_path} "
          f"({os.path.getsize(zip_path) / 1e6:.2f} MB)")


if __name__ == "__main__":
    main()
